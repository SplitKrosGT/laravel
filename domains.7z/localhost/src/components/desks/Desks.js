import './Desks.css';
import React, { useRef, useEffect, useState } from 'react';

function Desks() {

    const nameDesk = useRef(null);
    const [isUpdate, setIsUpdate] = useState(false);
    const [desks, setDesks] = useState([]);

    useEffect(() => {
        fetch('http://127.0.0.1:8000/api/desks')
            .then(res => res.json())
            .then((res) => {
                setDesks(res);
            })

    }, [isUpdate])

    const Create = () => {
        const ad = nameDesk.current.value;
        const data = {
            name: ad
        }
        console.log(ad);
        fetch("http://127.0.0.1:8000/api/create",
            {   
                method: 'POST',
                withCredentials: false,
                body: JSON.stringify(data),
                headers: {
                    'Content-Type': 'application/json'
                    // 'Content-Type': 'application/x-www-form-urlencoded',
                  },
            }
        )
            .then(() => {
                setIsUpdate(!isUpdate);
                
            });
    };


    return (
        <div className="Desks">
            {
                desks.map(desk => (
                    <div className='pidr' key={desk.id}>{desk.name}</div>
                ))
            }
            {
                <div>
                    <input ref={nameDesk} type="text"></input>
                    <button onClick={() => Create()}>Добавить</button>
                </div>
            }
        </div>
    );
}

export default Desks;

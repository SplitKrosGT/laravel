import './App.css';
import Desks from './components/desks/Desks';

function App() {
  return (
    <div className="App">
      <Desks />
    </div>
  );
}

export default App;

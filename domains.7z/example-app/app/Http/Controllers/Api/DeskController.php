<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Desk;

class DeskController extends Controller
{
    public function index()
    {
        return response()->json(Desk::all());
    }

    public function create(Request $request)
    {
        $newDesk = new Desk;
        $name = $request -> input("name");

        $newDesk -> name = $name;

        $newDesk -> save();

        return response()->json($newDesk);
    }
    
    public function show($id)
    {
        $desk = Desk::find($id);

        return response()->json($desk);
    }

    public function delete($id)
    {
        $desk = Desk::find($id);

        $desk -> delete();

        return response()->json('удалено');
    }
}
